// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysDetectorConstruction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Material.hh"
#include "G4Box.hh"

#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4ios.hh"

//***** Here maybe you include the proper .hh files for boolean operations.
#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::DetectorPhysDetectorConstruction()
  : logicWorld(0), physiWorld(0) {
}

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::~DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::Construct() {
  DefineMaterials();
  return ConstructSetUp();
}

//----------------------------------------------------------------------

void DetectorPhysDetectorConstruction::DefineMaterials() { 
  // This function illustrates the possible ways to define materials

  G4String name;
  G4double A, Z, density;
  G4double temperature, pressure;

  // Vacuum material
  name        = "Vacuum";
  density     = universe_mean_density;
  pressure    = 3.e-18*pascal;
  temperature = 2.73*kelvin;
  Z=1.;
  A=1.01*g/mole;
  Vacuum = new G4Material(name, Z, A, density, kStateGas, temperature, pressure);

  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::ConstructSetUp() {
  //
  // World
  //
  G4double WorldSizeX = 2.*m;
  G4double WorldSizeY = 2.*m;
  G4double WorldSizeZ = 2.*m;

  G4Box* solidWorld = new G4Box("World",                                   // its name
                                WorldSizeX/2, WorldSizeY/2, WorldSizeZ/2); // its size

  logicWorld = new G4LogicalVolume(solidWorld, // its solid
                                   Vacuum,     // default material,
                                   "World");   // its name

  physiWorld = new G4PVPlacement(0,               // no rotation
                                 G4ThreeVector(), // at (0,0,0)
                                 "World",         // its name
                                 logicWorld,      // its logical volume
                                 0,               // its mother  volume
                                 false,           // not used
                                 0);              // copy number


  //#### Step 0:
  //####   For Replicas don't forget to include the proper ".hh" file.

  //#### Replication in Z direction

  //#### Step 1: Mother Volume "Barrel" for Replicas
  //#### - Construct a solid "Cylinder_A" (using G4Tubs) as "barrel" region of a detector with:
  //####   R_min = 0 cm, R_max = 20 cm, L_z = 50 cm (full length), start_Phi = 0 deg, delta_Phi = 360 deg.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Place this cylinder in the world volume (its mother volume) at (0,0,0).
  //#### - Compile, execute, and visualize.


  //#### Step 2: Replicate Daughter Volume (5x)
  //#### - Construct a solid "Disk_A" (using G4Tubs) with:
  //####   appropriate values for R_min, R_max, L_z (full length), start_Phi, delta_Phi.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Replicate (use G4Replica class) this Disk_A five times inside the "Cylinder_A" along the Z axis (kZaxis).
  //#### - Compile, execute, and visualize.


  //#### Step 3: Place Detector Object inside Replicated Volumes
  //#### - Construct a solid "Ring_B" (using G4Tubs) with:
  //####   R_min = 10 cm, R_max = 20 cm, L_z = 2 cm (full length), start_Phi = 0 deg, delta_Phi = 360 deg.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Place it inside "Disk_A" as a mother volume at its origin.
  //#### - Compile, execute, and visualize.
  

  //#### Replication in Phi direction

  //#### Step 4: Mother Volume "EndCap" for Replicas
  //#### - Construct a solid "EndCap" (using G4Tubs) as "end cap" region of a detector with:
  //####   R_min = 5 cm, R_max = 30 cm, L_z = 0.5 cm (full lenth), start_Phi = 0 deg, delta_Phi = 360 deg.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Place this cylinder in the world volume as mother volume at (0,0,-30 cm).
  //#### - Compile, execute, and visualize.


  //#### Step 5: Replicate Daughter Volume (8x)
  //#### - Construct a "Wafer_Envelope" inside the so called "EndCap" Ring using G4Tubs with:
  //####   appropriate values for R_min, R_max, L_z (full length), start_Phi, delta_Phi.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Replicate the Wafer_Envelope eight times in the EndCap volume as a mother volume in Phi direction (kPhi).
  //#### - Compile, execute, and visualize.


  //#### Step 6: Place Detector Object inside Replicated Volumes
  //#### - Construct a Wafer (example of silicon wafer) with the shape of a ring's sector (using G4Tubs) with:
  //####   R_min = 5 cm, R_max = 30 cm, L_z = 0.5 cm (full length), start_Phi = 0 deg, delta_Phi = 30 deg.
  //#### - Construct its logical volume and fill it with vacuum material.
  //#### - Place this wafer at (0,0,0) of the Wafer-Envelope.
  //#### - Compile, execute, and visualize.


  //#### Step 7: Second "EndCap"
  //#### - Place a second EndCap at (0,0,30 cm). Don't forget to use a different copy number than before!
  //#### - Compile, execute, and visualize.


  // Visualization attributes

  //G4VisAttributes* yellow = new G4VisAttributes( G4Colour(255/255., 255/255.,   0/255.) );
  //G4VisAttributes* red    = new G4VisAttributes( G4Colour(255/255.,   0/255.,   0/255.) );
  //G4VisAttributes* roux   = new G4VisAttributes( G4Colour(204/255.,   0/255.,  51/255.) );
  //G4VisAttributes* brown  = new G4VisAttributes( G4Colour(255/255., 153/255., 153/255.) );
  //G4VisAttributes* metal  = new G4VisAttributes( G4Colour(204/255., 204/255., 255/255.) );
  //G4VisAttributes* Lbleu  = new G4VisAttributes( G4Colour(  0/255., 204/255., 204/255.) );
  //G4VisAttributes* Lgreen = new G4VisAttributes( G4Colour(153/255., 255/255., 153/255.) );

  //#### Step 8: Visualization Attributes
  //#### - Make all volumes but those which represent detector elements invisible.
  //#### - Colour Ring_B with colour "Lgreen".
  //#### - Colour Wafer yellow.
  //#### - Compile, execute, and visualize.

  //logicWorld->SetVisAttributes(G4VisAttributes::Invisible); // hide the box of the World volume
  //logicWorld->SetVisAttributes(red);


  //#### Step 9: Final Check
  //#### - Check geometry.


  return physiWorld;
}

//----------------------------------------------------------------------
