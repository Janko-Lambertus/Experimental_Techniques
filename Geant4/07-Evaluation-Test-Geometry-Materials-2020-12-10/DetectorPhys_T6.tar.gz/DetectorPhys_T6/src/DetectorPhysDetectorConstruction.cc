// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysDetectorConstruction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Material.hh"
#include "G4Box.hh"

#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4ios.hh"

#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"

//***** Here maybe you include the proper .hh files for boolean operations.


//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::DetectorPhysDetectorConstruction()
  : logicWorld(0), physiWorld(0) {
}

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::~DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::Construct() {
  DefineMaterials();
  return ConstructSetUp();
}

//----------------------------------------------------------------------

void DetectorPhysDetectorConstruction::DefineMaterials() { 
  // This function illustrates the possible ways to define materials

  G4String name, symbol;
  G4int    Z;
  G4double A, density;
  G4double temperature, pressure;

  //G4int ncomponents, natoms, nelements;
  //G4double fractionmass;

  // Vacuum material
  name        = "Vacuum";
  density     = universe_mean_density;
  pressure    = 3.e-18*pascal;
  temperature = 2.73*kelvin;
  Z = 1;
  A = 1.01*g/mole;
  Vacuum = new G4Material(name, Z, A, density, kStateGas, temperature, pressure);

  //#### Add your name here:
  //####   SOLUTION BY .....................

  //#### Define new materials for evaluation test.


  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::ConstructSetUp() {
  //
  // World
  //
  G4double WorldSizeX = 2.*m;
  G4double WorldSizeY = 2.*m;
  G4double WorldSizeZ = 2.*m;

  G4Box* solidWorld = new G4Box("World",                                   // its name
                                WorldSizeX/2, WorldSizeY/2, WorldSizeZ/2); // its size

  logicWorld = new G4LogicalVolume(solidWorld, // its solid
                                   Vacuum,     // default material,
                                   "World");   // its name

  physiWorld = new G4PVPlacement(0,               // no rotation
                                 G4ThreeVector(), // at (0,0,0)
                                 "World",         // its name
                                 logicWorld,      // its logical volume
                                 0,               // its mother  volume
                                 false,           // not used
                                 0);              // copy number

  //#### Construct the geometry of evaluation test


  // Visualization attributes

  //G4VisAttributes* yellow = new G4VisAttributes( G4Colour(255/255., 255/255.,   0/255.) );
  //G4VisAttributes* red    = new G4VisAttributes( G4Colour(255/255.,   0/255.,   0/255.) );
  //G4VisAttributes* roux   = new G4VisAttributes( G4Colour(204/255.,   0/255.,  51/255.) );
  //G4VisAttributes* brown  = new G4VisAttributes( G4Colour(255/255., 153/255., 153/255.) );
  //G4VisAttributes* metal  = new G4VisAttributes( G4Colour(204/255., 204/255., 255/255.) );
  //G4VisAttributes* Lbleu  = new G4VisAttributes( G4Colour(  0/255., 204/255., 204/255.) );
  //G4VisAttributes* Lgreen = new G4VisAttributes( G4Colour(153/255., 255/255., 153/255.) );

  logicWorld->SetVisAttributes(G4VisAttributes::Invisible); // hide the box of the World volume
  //logicWorld->SetVisAttributes(red);

  return physiWorld;
}

//----------------------------------------------------------------------
