// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysTrackingAction_h
#define DetectorPhysTrackingAction_h 1

#include "G4UserTrackingAction.hh"
#include "globals.hh"

//----------------------------------------------------------------------

class DetectorPhysTrackingAction : public G4UserTrackingAction {
  public:
    DetectorPhysTrackingAction();
    virtual ~DetectorPhysTrackingAction() {};

    virtual void PreUserTrackingAction(const G4Track*);
    virtual void PostUserTrackingAction(const G4Track*);
};

//----------------------------------------------------------------------

#endif
