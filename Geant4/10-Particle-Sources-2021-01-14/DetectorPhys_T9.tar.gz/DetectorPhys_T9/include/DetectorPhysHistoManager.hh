// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysHistoManager_h
#define DetectorPhysHistoManager_h 1

#include "globals.hh"

#include "g4root.hh"
//#include "g4xml.hh"

//----------------------------------------------------------------------

class DetectorPhysHistoManager {
  public:
    DetectorPhysHistoManager();
    virtual ~DetectorPhysHistoManager();

  private:
    void Book();
    G4String fFileName;
};

//----------------------------------------------------------------------

#endif
