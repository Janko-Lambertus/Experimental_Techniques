// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysPrimaryGeneratorAction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "globals.hh"

//----------------------------------------------------------------------

DetectorPhysPrimaryGeneratorAction::DetectorPhysPrimaryGeneratorAction(DetectorPhysDetectorConstruction* DetectorPhysDC)
  : DetectorPhysDetector(DetectorPhysDC) {
  G4int n_particle = 1;
  particleGun  = new G4ParticleGun(n_particle);

  // default particle kinematic

// G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
// G4String particleName;
// G4ParticleDefinition* particle = particleTable->FindParticle(particleName="gamma");
// particleGun->SetParticleDefinition(particle);
// particleGun->SetParticleMomentumDirection(G4ThreeVector(0.,0.,-1.));
// particleGun->SetParticleEnergy(10.*MeV);
// particleGun->SetParticlePosition(G4ThreeVector(-457.2*mm,0.*mm,1000.*mm));
}

//----------------------------------------------------------------------

DetectorPhysPrimaryGeneratorAction::~DetectorPhysPrimaryGeneratorAction() {
  delete particleGun;
}

//----------------------------------------------------------------------

void DetectorPhysPrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) {

//// example: set particle starting point within the source code
// G4double x0_Offset; x0_Offset = 0.0*m;
// G4double y0_Offset; y0_Offset = 0.0*m;
// G4double z0_Offset; z0_Offset = 5.5*m
// particleGun->SetParticlePosition(G4ThreeVector(x0_Offset,y0_Offset,z0_Offset));
////

  particleGun->GeneratePrimaryVertex(anEvent);
}

//----------------------------------------------------------------------
