// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysHistoManager.hh"
#include "G4UnitsTable.hh"

//----------------------------------------------------------------------

DetectorPhysHistoManager::DetectorPhysHistoManager()
  : fFileName("DetectorPhys_T9") {
  Book();
}

//----------------------------------------------------------------------

DetectorPhysHistoManager::~DetectorPhysHistoManager() {
  delete G4AnalysisManager::Instance();
}

//----------------------------------------------------------------------

void DetectorPhysHistoManager::Book() {
  // Create or get analysis manager
  // The choice of analysis technology is done via selection of a namespace
  // in HistoManager.hh
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  analysisManager->SetFileName(fFileName);
  analysisManager->SetVerboseLevel(1);
  analysisManager->SetActivation(true);     //enable inactivation of histograms
  
  // Default values (to be reset via /analysis/h1/set command)
  G4int nbins = 100;
  G4double vmin = 0.;
  G4double vmax = 100.;

  // Create all histograms as inactivated 
  // as we have not yet set nbins, vmin, vmax
  //
  analysisManager->SetHistoDirectoryName("histo");  
  analysisManager->SetFirstHistoId(1);

  G4int id = analysisManager->CreateH1("h1.1","kinetic energy", nbins, vmin, vmax);
  analysisManager->SetH1Activation(id, false);

  id = analysisManager->CreateH1("h1.2","direction: cos(theta)", nbins, vmin, vmax);
  analysisManager->SetH1Activation(id, false);

  id = analysisManager->CreateH1("h1.3","direction: theta", nbins, vmin, vmax);
  analysisManager->SetH1Activation(id, false);

  id = analysisManager->CreateH1("h1.4","direction: phi", nbins, vmin, vmax);
  analysisManager->SetH1Activation(id, false);

  // histos 2D
  //
  id = analysisManager->CreateH2("h2.1","vertex: XY",nbins,vmin,vmax, nbins,vmin,vmax);
  analysisManager->SetH2Activation(id, false);

  id = analysisManager->CreateH2("h2.2","vertex: YZ",nbins,vmin,vmax, nbins,vmin,vmax);
  analysisManager->SetH2Activation(id, false);

  id = analysisManager->CreateH2("h2.3","vertex: ZX",nbins,vmin,vmax, nbins,vmin,vmax);
  analysisManager->SetH2Activation(id, false);

  id = analysisManager->CreateH2("h2.4","direction: phi-cos(theta)",
                                          nbins,vmin,vmax, nbins,vmin,vmax);
  analysisManager->SetH2Activation(id, false);

  id = analysisManager->CreateH2("h2.5","direction: phi-theta",
                                          nbins,vmin,vmax, nbins,vmin,vmax);
  analysisManager->SetH2Activation(id, false);
}

//----------------------------------------------------------------------
