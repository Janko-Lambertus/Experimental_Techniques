// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysRunAction.hh"
#include "DetectorPhysPrimaryGeneratorAction.hh"
#include "DetectorPhysHistoManager.hh"
#include "G4Run.hh"
#include "G4UImanager.hh"
#include "G4VVisManager.hh"
#include "G4ios.hh"

//----------------------------------------------------------------------

DetectorPhysRunAction::DetectorPhysRunAction()
 : G4UserRunAction(), fHistoManager(0) {
  fHistoManager = new DetectorPhysHistoManager();
}

//----------------------------------------------------------------------

DetectorPhysRunAction::~DetectorPhysRunAction() {
  delete fHistoManager;
}

//----------------------------------------------------------------------

// Begin of Run Action
void DetectorPhysRunAction::BeginOfRunAction(const G4Run*) {
  //histograms
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  if ( analysisManager->IsActive() ) {
    analysisManager->OpenFile();
  }
}

//----------------------------------------------------------------------

// End of Run Action
void DetectorPhysRunAction::EndOfRunAction(const G4Run*) {
  //save histograms
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  if ( analysisManager->IsActive() ) {
    analysisManager->Write();
    analysisManager->CloseFile();
  }
}

//----------------------------------------------------------------------
