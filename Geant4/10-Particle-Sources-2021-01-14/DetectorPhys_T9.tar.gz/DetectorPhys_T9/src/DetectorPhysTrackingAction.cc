// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysTrackingAction.hh"
#include "DetectorPhysHistoManager.hh"

#include "G4Track.hh"
#include "G4PhysicalConstants.hh"
#include "G4ios.hh"

//----------------------------------------------------------------------

DetectorPhysTrackingAction::DetectorPhysTrackingAction()
 : G4UserTrackingAction() {
}

//----------------------------------------------------------------------

void DetectorPhysTrackingAction::PreUserTrackingAction(const G4Track* track) {
  //G4int pid               = track->GetDynamicParticle()->GetPDGcode();
  G4double ekin           = track->GetKineticEnergy();
  G4ThreeVector vertex    = track->GetPosition();
  G4ThreeVector direction = track->GetMomentumDirection();
  //G4double weight         = track->GetWeight();

  G4double x = vertex.x(), y = vertex.y(), z = vertex.z();
  G4double theta = direction.theta(), phi = direction.phi();
  if (phi < 0.) phi += twopi;
  G4double cost = std::cos(theta);

  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

  // fill histograms
  analysisManager->FillH1(1,ekin);
  analysisManager->FillH1(2,cost);
  analysisManager->FillH1(3,theta);
  analysisManager->FillH1(4,phi);
  analysisManager->FillH2(1,x,y);
  analysisManager->FillH2(2,y,z);
  analysisManager->FillH2(3,z,x);
  analysisManager->FillH2(4,phi,cost);
  analysisManager->FillH2(5,phi,theta);
}

//----------------------------------------------------------------------

void DetectorPhysTrackingAction::PostUserTrackingAction(const G4Track*) {
}

//----------------------------------------------------------------------


