// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysDetectorConstruction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4PVReplica.hh"

#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4ios.hh"

#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"

//***** Here maybe you include the proper .hh files for boolean operations.


//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::DetectorPhysDetectorConstruction()
  : logicWorld(0), physiWorld(0), LogicalChamberGasBox(0), PhysicalChamberGasBox(0) {
}

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::~DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::Construct() {
  DefineMaterials();
  return ConstructSetUp();
}

//----------------------------------------------------------------------

void DetectorPhysDetectorConstruction::DefineMaterials() { 
  // This function illustrates the possible ways to define materials

  G4String name, symbol;
  G4int    Z;
  G4double A, density;
  G4double temperature, pressure;

  G4int ncomponents, natoms, nelements;
  G4double fractionmass;

  // Vacuum material
  name        = "Vacuum";
  density     = universe_mean_density;
  pressure    = 3.e-18*pascal;
  temperature = 2.73*kelvin;
  Z = 1;
  A = 1.01*g/mole;
  Vacuum = new G4Material(name, Z, A, density, kStateGas, temperature, pressure);

  // Define Elements
  name   = "Element_Iodine";
  symbol = "I";
  Z      = 53;
  A      = 126.904*g/mole;
  G4Element* elI  = new G4Element(name, symbol, Z, A);

  name   = "Element Cesium" ;
  symbol = "Cs";
  Z      = 55;
  A      = 132.905*g/mole;
  G4Element* elCs  = new G4Element(name, symbol, Z, A);

  name   = "Element_Hydrogen";
  symbol = "H"; 
  Z      = 1;
  A      = 1.00794*g/mole;
  G4Element* elH = new G4Element(name, symbol, Z, A);

  name   = "Element_Carbon";
  symbol = "C";
  Z      = 6;
  A      = 12.011*g/mole;
  G4Element* elC = new G4Element(name, symbol, Z, A);

  name   = "Element_Nitrogen";
  symbol = "N"; 
  Z      = 7;
  A      = 14.01*g/mole;
  G4Element* elN = new G4Element(name, symbol, Z, A);

  name   = "Element_Oxygen";
  symbol = "O"; 
  Z      = 8;
  A      = 16.00*g/mole;
  G4Element* elO = new G4Element(name, symbol, Z, A);

  name   = "Element_Aluminum";
  symbol = "Al"; 
  Z      = 13;
  A      = 26.981539*g/mole;
  G4Element* elAl = new G4Element(name, symbol, Z, A);

  name   = "Element_Silicon";
  symbol = "Si"; 
  Z      = 14;
  A      = 28.09*g/mole;
  G4Element* elSi  = new G4Element(name, symbol, Z, A);

  name   = "Element_Argon";
  symbol = "Ar"; 
  Z      = 18;
  A      = 39.95*g/mole;
  G4Element* elAr  = new G4Element(name, symbol, Z, A);

  name   = "Element_Iron";
  symbol = "Fe";
  Z      = 26;
  A      = 55.85*g/mole;
  G4Element* elFe  = new G4Element(name, symbol, Z, A);

  name   = "Cobalt";
  symbol = "Co";
  Z      = 27;
  A      = 58.9332*g/mole;
  G4Element* elCo = new G4Element(name, symbol, Z, A);

  name   = "Element_Fluorine";
  symbol = "F"; 
  Z      = 9;
  A      = 19.00*g/mole;
  G4Element* elF = new G4Element(name, symbol, Z, A);

  // gaseous Argon, STP
  name      = "ArgonGas";
  density   = 1.7836*mg/cm3;
  nelements = 1;
  G4Material* matArgonGas = new G4Material(name, density, nelements, kStateGas, 293.15*kelvin, 1.*atmosphere);
              matArgonGas->AddElement(elAr, 1);

  // gaseous CF4
  name      = "CF4";
  density   = 3.924*mg/cm3;
  nelements = 2;
  G4Material* matCF4 = new G4Material(name, density, nelements, kStateGas, 293.15*kelvin, 0.1*atmosphere);
              matCF4->AddElement(elC, 1);
              matCF4->AddElement(elF, 4);

  // gaseous C4H10 : iso-Butane (methylpropane), STP
  name        = "IsoButane";
  density     = 2.67*mg/cm3 ;
  ncomponents = 2;
  G4Material* matIsobutane = new G4Material(name, density, ncomponents);
              matIsobutane->AddElement(elC,natoms= 4);
              matIsobutane->AddElement(elH,natoms=10);

  // gaseous Ar:CF4:iC4H10 (95:3:2)
  name        = "Ar_CF4_iC4H10";
  density     = 1.88418*mg/cm3;
  ncomponents = 3;
  G4Material* matAr_CF4_iC4H10 = new G4Material(name, density, ncomponents, kStateGas, 293.15*kelvin, 10.0*atmosphere);
              matAr_CF4_iC4H10->AddMaterial(matArgonGas,  fractionmass=0.95);
              matAr_CF4_iC4H10->AddMaterial(matCF4,       fractionmass=0.03);
              matAr_CF4_iC4H10->AddMaterial(matIsobutane, fractionmass=0.02);

  // gaseous CO2, STP
  name        = "CO2";
  density     = 1.818*mg/cm3;
  ncomponents = 2;
  G4Material* matCO2 = new G4Material(name, density, ncomponents, kStateGas, 293.15*kelvin, 1.*atmosphere);
              matCO2->AddElement(elC, natoms=1);
              matCO2->AddElement(elO, natoms=2);

  // gaseous Air material: Air 20 degr.C and 58% humidity
  name        = "Air";
  density     = 1.214*mg/cm3;
  ncomponents = 4;
  G4Material* matAir = new G4Material(name, density, ncomponents, kStateGas, 293.15*kelvin, 1.*atmosphere);
              matAir->AddElement(elN,  fractionmass=0.7494);
              matAir->AddElement(elO,  fractionmass=0.2369);
              matAir->AddElement(elAr, fractionmass=0.0129);
              matAir->AddElement(elH,  fractionmass=0.0008);

  // Platic Scintillator
  name        = "Scintillator";
  density     = 1.032*g/cm3;
  ncomponents = 2;
  G4Material* matScint = new G4Material(name, density, ncomponents);
              matScint->AddElement(elC, natoms=9);
              matScint->AddElement(elH, natoms=10);

  // Mylar
  name        = "Mylar";
  density     = 1.397*g/cm3;
  ncomponents = 3;
  G4Material* matMylar = new G4Material(name, density, ncomponents);
              matMylar->AddElement(elH, natoms= 8);
              matMylar->AddElement(elC, natoms=10);
              matMylar->AddElement(elO, natoms= 4);

  // Nema grade G10 or FR4
  name        = "NemaG10";
  density     = 1.70*g/cm3;
  ncomponents = 4;
  G4Material* matG10 = new G4Material(name, density, ncomponents);
              matG10->AddElement(elSi, natoms=1);
              matG10->AddElement(elO,  natoms=2);
              matG10->AddElement(elC,  natoms=3);
              matG10->AddElement(elH,  natoms=3);

  // Kapton
  name        = "Kapton";
  density     = 1.42*g/cm3;
  ncomponents = 4;
  G4Material* matKapton = new G4Material(name, density, ncomponents);
              matKapton->AddElement(elH, fractionmass = 0.0273);
              matKapton->AddElement(elC, fractionmass = 0.7213);
              matKapton->AddElement(elN, fractionmass = 0.0765);
              matKapton->AddElement(elO, fractionmass = 0.1749);

  // stainless steel
  name="Steel";
  density=7.7*g/cm3;
  ncomponents=3;
  G4Material* matSsteel = new G4Material(name, density, ncomponents);
              matSsteel->AddElement(elC,  0.04);
              matSsteel->AddElement(elFe, 0.88);
              matSsteel->AddElement(elCo, 0.08);

  // CsI (Cesium Iodine)
  name      = "CesiumIodide";
  density   = 4.53*g/cm3;
  nelements = 2;
  G4Material* matCsI = new G4Material(name, density, nelements);
              matCsI->AddElement(elCs, natoms=5);
              matCsI->AddElement(elI,  natoms=5);

  // Al material
  name      = "Aluminum";
  density   = 2.700*g/cm3;
  nelements = 1;
  G4Material* matAl = new G4Material(name, density, nelements);
              matAl -> AddElement(elAl,1);

  Air_Material = matAir;
  Al_Material = matAl;

  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::ConstructSetUp() {
  //
  // World
  //
  G4double WorldSizeX = 2.*m;
  G4double WorldSizeY = 2.*m;
  G4double WorldSizeZ = 2.*m;

  G4Box* solidWorld = new G4Box("World",                                   // its name
                                WorldSizeX/2, WorldSizeY/2, WorldSizeZ/2); // its size

  logicWorld = new G4LogicalVolume(solidWorld,   // its solid
                                   Air_Material, // default material,
                                   "World");     // its name

  physiWorld = new G4PVPlacement(0,               // no rotation
                                 G4ThreeVector(), // at (0,0,0)
                                 "World",         // its name
                                 logicWorld,      // its logical volume
                                 0,               // its mother  volume
                                 false,           // not used
                                 0);              // copy number

  // Solution of Tutorial 4

  // Replication in Z direction
  // Big Cylinder

  G4double BigCylinderRMin =   0.*cm;
  G4double BigCylinderRMax =  20.*cm;
  G4double BigCylinderLz   =  50.*cm;
  G4double BigCylinderPhiS =   0.*deg;
  G4double BigCylinderPhiE = 360.*deg;

  G4Tubs* SolidBigCylinder = new G4Tubs("SolidBigCylinder", BigCylinderRMin, BigCylinderRMax, BigCylinderLz/2, BigCylinderPhiS, BigCylinderPhiE);
  G4LogicalVolume* LogicalBigCylinder = new G4LogicalVolume(SolidBigCylinder, Air_Material, "LogicalBigCylinder");

  //G4VPhysicalVolume* PhysicalBigCylinder =
                                           new G4PVPlacement(0,			       // no rotation
  							     G4ThreeVector(0,0,0.*cm), // at (0,0,0)
							     "PhysicalBigCylinder",    // its name
							     LogicalBigCylinder,       // its logical volume
							     physiWorld,	       // its mother  volume
							     false,		       // not used
							     0);		       // copy number

  G4double SmallCylinderRMin =  10.*cm;
  G4double SmallCylinderRMax =  20.*cm;
  G4double SmallCylinderLz   =  10.*cm;
  G4double SmallCylinderPhiS =   0.*deg;
  G4double SmallCylinderPhiE = 360.*deg;

  G4Tubs* SolidSmallCylinder = new G4Tubs("SolidSmallCylinder", SmallCylinderRMin, SmallCylinderRMax, SmallCylinderLz/2., SmallCylinderPhiS, SmallCylinderPhiE);

  G4LogicalVolume* LogicalSmallCylinder = new G4LogicalVolume(SolidSmallCylinder, Air_Material, "LogicalSmallCylinder");

  G4PVReplica* repSmallCylinder= new G4PVReplica("Linear Array",
 					         LogicalSmallCylinder,
 					         LogicalBigCylinder,
 					         kZAxis,
 					         5,
 					         10.*cm);

  G4double SmallCylinderRMin_Al =  10.*cm;
  G4double SmallCylinderRMax_Al =  20.*cm;
  G4double SmallCylinderLz_Al   =   2.*cm;
  G4double SmallCylinderPhiS_Al =   0.*deg;
  G4double SmallCylinderPhiE_Al = 360.*deg;

  G4Tubs* SolidSmallCylinder_Al = new G4Tubs("SolidSmallCylinder_Al", SmallCylinderRMin_Al, SmallCylinderRMax_Al, SmallCylinderLz_Al/2, SmallCylinderPhiS_Al, SmallCylinderPhiE_Al);

  G4LogicalVolume* LogicalSmallCylinder_Al = new G4LogicalVolume(SolidSmallCylinder_Al, Al_Material, "LogicalSmallCylinder_Al");

  //G4VPhysicalVolume* repSmallCylinder_Al =
                                           new G4PVPlacement(0,			       // no rotation
 							     G4ThreeVector(0,0,0.*cm), // at (0,0,0)
							     "PhysicalBigCylinder_Al", // its name
							     LogicalSmallCylinder_Al,  // its logical volume
							     repSmallCylinder,	       // its mother  volume
							     false,		       // not used
							     0);		       // copy number
  // Replication in Phi direction
  // Mother Volume

  G4double MCylinderRMin =   5. *cm;
  G4double MCylinderRMax =  30. *cm;
  G4double MCylinderLz =     0.5*cm;
  G4double MCylinderPhiS =   0. *deg;
  G4double MCylinderPhiE = 360. *deg;

  G4Tubs* SolidMCylinder = new G4Tubs("SolidMCylinder", MCylinderRMin, MCylinderRMax, MCylinderLz/2, MCylinderPhiS, MCylinderPhiE);
  G4LogicalVolume* LogicalMCylinder = new G4LogicalVolume(SolidMCylinder, Air_Material, "LogicalMCylinder");

  //G4VPhysicalVolume* PhysicalMCylinder =
                                         new G4PVPlacement(0,			       // no rotation
							   G4ThreeVector(0,0,-30.*cm), // at (0,0,-30 cm)
							   "PhysicalMCylinder",	       // its name
							   LogicalMCylinder,	       // its logical volume
							   physiWorld,		       // its mother  volume
							   false,		       // not used
							   0);			       //copy number

  // Daugther Volume

  G4double CylinderRMin =  5. *cm;
  G4double CylinderRMax = 30. *cm;
  G4double CylinderLz   =  0.5*cm;
  G4double CylinderPhiS =  0. *deg;
  G4double CylinderPhiE = 45. *deg;

  G4Tubs* SolidCylinder = new G4Tubs("SolidCylinder", CylinderRMin, CylinderRMax, CylinderLz/2, CylinderPhiS, CylinderPhiE);
  G4LogicalVolume* LogicalCylinder = new G4LogicalVolume(SolidCylinder, Air_Material, "LogicalCylinder");
  
  G4PVReplica* repRZPhi = new G4PVReplica("RZPhiSlices",
					  LogicalCylinder,
					  LogicalMCylinder,
					  kPhi,
					  8, 
					  (M_PI/4.)*rad,
					  0);


  G4double CylinderRMin_w =  5. *cm;
  G4double CylinderRMax_w = 30. *cm;
  G4double CylinderLz_w =    0.5*cm;
  G4double CylinderPhiS_w =  0. *deg;
  G4double CylinderPhiE_w = 30. *deg;
  
  G4Tubs* SolidCylinder_w = new G4Tubs("SolidCylinder", CylinderRMin_w, CylinderRMax_w, CylinderLz_w/2, CylinderPhiS_w, CylinderPhiE_w);
  G4LogicalVolume* LogicalCylinder_w = new G4LogicalVolume(SolidCylinder_w, Al_Material, "LogicalCylinder_w");

  //G4VPhysicalVolume* PhysicalCylinder_w =
                                          new G4PVPlacement(0,		              // no rotation
					                    G4ThreeVector(0,0,0.*cm), // at (0,0,0)
					                    "PhysicalCylinder_w",     // its name
					                    LogicalCylinder_w,	      // its logical volume
					                    repRZPhi,		      // its mother  volume
					                    false,		      // not used
					                    0);			      // copy number

  //PhysicalMCylinder =
		      new G4PVPlacement(0,			   // no rotation
				        G4ThreeVector(0,0,30.*cm), // at (0,0,30 cm)
					"PhysicalMCylinder",	   // its name
					LogicalMCylinder,	   // its logical volume
					physiWorld,		   // its mother  volume
					false,			   // not used
					1);			   // copy number

  // Visualization attributes

  G4VisAttributes* yellow = new G4VisAttributes( G4Colour(255/255., 255/255.,   0/255.) );
  //G4VisAttributes* red    = new G4VisAttributes( G4Colour(255/255.,   0/255.,   0/255.) );
  //G4VisAttributes* roux   = new G4VisAttributes( G4Colour(204/255.,   0/255.,  51/255.) );
  //G4VisAttributes* brown  = new G4VisAttributes( G4Colour(255/255., 153/255., 153/255.) );
  //G4VisAttributes* metal  = new G4VisAttributes( G4Colour(204/255., 204/255., 255/255.) );
  //G4VisAttributes* Lbleu  = new G4VisAttributes( G4Colour(  0/255., 204/255., 204/255.) );
  G4VisAttributes* Lgreen = new G4VisAttributes( G4Colour(153/255., 255/255., 153/255.) );

  logicWorld->SetVisAttributes(G4VisAttributes::Invisible); // hide the box of the World volume

  LogicalBigCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalSmallCylinder->SetVisAttributes(G4VisAttributes::Invisible);

  LogicalMCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalSmallCylinder_Al->SetVisAttributes(Lgreen);

  LogicalCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalCylinder_w->SetVisAttributes(yellow);

  // (Step 9: Final Check)

  return physiWorld;
}

//----------------------------------------------------------------------
