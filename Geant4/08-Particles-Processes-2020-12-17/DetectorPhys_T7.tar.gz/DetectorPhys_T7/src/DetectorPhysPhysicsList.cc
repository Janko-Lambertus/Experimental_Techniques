// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysPhysicsList.hh"

//----------------------------------------------------------------------

DetectorPhysPhysicsList::DetectorPhysPhysicsList():  G4VUserPhysicsList() {
}

//----------------------------------------------------------------------

DetectorPhysPhysicsList::~DetectorPhysPhysicsList() {
}

//----------------------------------------------------------------------

void DetectorPhysPhysicsList::ConstructParticle() {
  //#### Step 0:
  //#### - Make sure that G4ParticleTypes.hh is included.
  //#### - What are the default particle parameters in the file "vis_T7.mac"?


  //#### Step 1
  //#### - Construct a Photon (Gamma):
  //#### - Compile and run your program.
  //#### - Shoot 100 particles ("/run/beamOn 100"). What do you see (knowing that the default particle is a photon (gamma))?
  //#### - Change the particle type in the session ("/gun/particle e-" or "/gun/particle e+"). What do you see?


  //#### Step 2
  //#### - Construct the electron.
  //#### - Compile and run your program.
  //#### - Shoot 100 particles ("/run/beamOn 100"). What do you see?


  //#### Step 3
  //#### - Construct the positron.
  //#### - Compile and run your program.
  //#### - Shoot 100 particles ("/run/beamOn 100"). What do you see?

}

//----------------------------------------------------------------------

void DetectorPhysPhysicsList::ConstructProcess() {
  AddTransportation();
  auto particleIterator = GetParticleIterator();
  particleIterator->reset();
  while( (*particleIterator)() ){
    //#### Step 4
    //#### - Define and get the current particle from the particle iterator.


    //#### Step 5
    //#### - Get the particle name of the current particle and store it in particleName.
    G4String particleName;


    //#### Step 6
    //#### - Define and get the process manager of the current particle.
    //#### - Make sure that G4ProcessManager.hh and the header files of all processes are included.
    //#### - Compile and run your program.
    //#### - Shoot 100 particles ("/run/beamOn 100"). What do you see?


    if (particleName == "gamma") {                                                 // photon
      //#### Step 7
      //#### - Construct and add the photo-electric process for gammas.
      //#### - Compile and run your program (if compilation fails, what is the solution?)
      //#### - Shoot 100 particles ("/run/beamOn 100"). What do you see?
      //#### - The default particle (gamma) energy is set to 10 MeV in the file "vis_T7.mac".
      //#### - Change its energy to 100 keV ("/gun/energy 100 keV") and shoot 100 particles ("/run/beamOn 100"). What do you see?
      //#### - Change its energy to 10 keV ("/gun/energy 10 keV") and shoot 100 particles ("/run/beamOn 100"). What do you see?


      //#### Step 8
      //#### - Add all possible related processes.


    } else if (particleName == "e-") {                                             // electron
      //#### Step 9
      //#### - Constrcut and add all possible processes for electrons.


    } else if (particleName == "e+") {                                             // positron
      //#### Step 10
      //#### - Constrcut and add all possible processes for positrons.


      //#### Step 11
      //#### - Play with your simulation:
      //####   * Vary the energy, position, and direction of the particles.
      //####   * Change the particle type.
      //####   * Comment out all but one process at a time. Do not forget to compile and re-run the simulation. Try to interpret the visualization.
    }
  }
}

//----------------------------------------------------------------------

void DetectorPhysPhysicsList::SetCuts() {
  G4int temp = GetVerboseLevel();
  SetVerboseLevel(0);
  SetCutsWithDefault();
  SetVerboseLevel(temp);
}

//----------------------------------------------------------------------
