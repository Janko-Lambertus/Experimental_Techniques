// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysDetectorConstruction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4PVReplica.hh"

#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4ios.hh"

#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"




//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::DetectorPhysDetectorConstruction()
  : logicWorld(0), physiWorld(0) {
}

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::~DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::Construct() {
  DefineMaterials();
  return ConstructSetUp();
}

//----------------------------------------------------------------------

void DetectorPhysDetectorConstruction::DefineMaterials() { 
  // This function illustrates the possible ways to define materials

  G4String name, symbol;
  G4int    Z;
  G4double A, density;
  G4double temperature, pressure;

  G4int ncomponents, natoms, nelements;
  G4double fractionmass;

  // Vacuum material
  name        = "Vacuum";
  density     = universe_mean_density;
  pressure    = 3.e-18*pascal;
  temperature = 2.73*kelvin;
  Z = 1;
  A = 1.01*g/mole;
  Vacuum = new G4Material(name, Z, A, density, kStateGas, temperature, pressure);


  //#### Step 0
  //#### - Check which material is used in all logical volumes of the geometry (see below). (It should be Vacuum)
  //#### - Compile first, then /run/beamOn 100. What do you see and why? (nothing in principle)
  //#### - Check whether G4Material.hh is included


  //#### Step 1
  //#### - Understand the example how gaseous Argon (at STP) and pure Aluminium are defined.

  // define some elements

  name   = "Element_Argon";
  symbol = "Ar"; 
  Z      = 18;
  A      = 39.95*g/mole;
  G4Element* elAr  = new G4Element(name, symbol, Z, A);

  name   = "Element_Aluminum";
  symbol = "Al";
  Z      = 13;
  A      = 26.981539*g/mole;
  G4Element* elAl = new G4Element(name, symbol, Z, A);
 

  // define some materials
  
  //  Material:  Argon Gas                     density:  1.784 mg/cm3 at STP (standard temperature and pressure)
  //    - Elements:  * Element_Argon (Ar)     Z = 18   N =  40   A =  39.95 g/mole
  name      = "ArgonGas";
  density   = 1.7836*mg/cm3;
  nelements = 1;
  G4Material* matArgonGas = new G4Material(name, density, nelements, kStateGas, 293.15*kelvin, 1.*atmosphere);
              matArgonGas->AddElement(elAr, 1);

  //  Material:  Alumnium                      density:  2.700 g/cm3
  name      = "Aluminum";
  density   = 2.700*g/cm3;
  nelements = 1;
  G4Material* matAl = new G4Material(name, density, nelements);
              matAl->AddElement(elAl, 1);


  //#### Step 2
  //#### - Define CF4 using number of atomes in CF4.
  //  Material:  CF4                           density:  3.924 mg/cm3
  //    -  Elements: * Element_Carbon (C)     Z =  6   N =  12   A =  12.01 g/mole
  //                 * Element_Fluorine (F)   Z =  9   N =  19   A =  19.00 g/mole


  //#### Step 3
  //#### - Define C4H10 (Isobutane) using number of atomes in C4H10.
  //  Material:  Isobutane                     density:  2.670 mg/cm3
  //    - Elements:  * Element_Carbon (C)     Z =  6   N =  12   A =  12.01 g/mole
  //                 * Element_Hydrogen (H)   Z =  1   N =   1   A =   1.01 g/mole


  //#### Step 4
  //#### - Define a gas mixture of Argon, CF4, and Isobutane.
  //#### - Replace the material of LogicalCylinder_w in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)
  //#### - Replace the material of LogicalSmallCylinder_Si in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)
  //  Material:  Ar_CF4_iC4H10 (95%, 3%, 2%)   density:  1.884 mg/cm3



  //#### Step 5
  //#### - Define air using fractionmass.
  //  Material:  Air                           density:  1.205 mg/cm3 
  //    - Elements:  * Element_Nitrogen (N)   Z =  7   N =  14   A =  14.01 g/mole   ElmMassFraction:  74.94 %
  //                 * Element_Oxygen (O)     Z =  8   N =  16   A =  16.00 g/mole   ElmMassFraction:  23.69 %
  //                 * Element_Argon (Ar)     Z = 18   N =  40   A =  39.95 g/mole   ElmMassFraction:   1.29 %
  //                 * Element_Hydrogen (H)   Z =  1   N =   1   A =   1.01 g/mole   ElmMassFraction:   0.08 %


  //#### Step 6
  //#### - Define steel.
  //#### - Replace the material of LogicalCylinder_w in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)
  //#### - Replace the material of LogicalSmallCylinder_Si in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)
  //  Material:  Steel                         density:  7.700 g/cm3
  //    - Elements:  * Element_Carbon (C)     Z =  6   N =  12   A =  12.01 g/mole   fractionmass = 0.04
  //                 * Element_Iron (Fe)      Z = 26   N =  55   A =  55.85 g/mole   fractionmass = 0.88
  //                 * Element_Cobalt (Co)    Z = 27   N =  58   A =  58.93 g/mole   fractionmass = 0.08


  //#### Step 7
  //#### - Define a more realistic material with isotopes using water as an example.
  //  Material:  Water (H2O)                   density:  1.000 g/cm3
  //    - Elements:  * Element_H (H)
  //                     - Isotopes:  * H1    Z =  1   N =   1   A =   1.01 g/mole   abundance:  99.99 %
  //                                  * H2    Z =  1   N =   2   A =   2.01 g/mole   abundance:   0.01 %
  //                 * Element_O (O)
  //                     - Isotopes:  * O16   Z =  8   N =  16   A =  15.99 g/mole   abundance:  99.76 %
  //                                  * O17   Z =  8   N =  17   A =  17.00 g/mole   abundance:   0.04 %
  //                                  * O18   Z =  8   N =  18   A =  18.00 g/mole   abundance:   0.20 %


  //#### Step 8
  //#### - Construct water using the NIST Manager.


  //#### Step 9
  //#### - Construct copper using the NIST Manager.


  //#### Step 10
  //#### - Construct the crystal scintillator CsI(Tl 5%) using your preferred method.
  //#### - Replace the material of LogicalCylinder_w in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)
  //#### - Replace the material of LogicalSmallCylinder_Si in the geometry set-up by this new material, then /run/beamOn 100 (What do you see?)


  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::ConstructSetUp() {
  //
  // World
  //
  G4double WorldSizeX = 2.*m;
  G4double WorldSizeY = 2.*m;
  G4double WorldSizeZ = 2.*m;

  G4Box* solidWorld = new G4Box("World",                                   // its name
                                WorldSizeX/2, WorldSizeY/2, WorldSizeZ/2); // its size

  logicWorld = new G4LogicalVolume(solidWorld, // its solid
                                   Vacuum,     // default material,
                                   "World");   // its name

  physiWorld = new G4PVPlacement(0,               // no rotation
                                 G4ThreeVector(), // at (0,0,0)
                                 "World",         // its name
                                 logicWorld,      // its logical volume
                                 0,               // its mother  volume
                                 false,           // not used
                                 0);              // copy number

  // Solution of Tutorial 4
  // (The names of the objects are different.)
  
  // (Step 0:)


  // Replication in Z direction

  // (Step 1: Mother Volume "Barrel" for Replicas)

  // Big Cylinder

  G4double BigCylinderRMin =   0.*cm;
  G4double BigCylinderRMax =  20.*cm;
  G4double BigCylinderLz   =  50.*cm;
  G4double BigCylinderPhiS =   0.*deg;
  G4double BigCylinderPhiE = 360.*deg;

  G4Tubs* SolidBigCylinder = new G4Tubs("SolidBigCylinder", BigCylinderRMin, BigCylinderRMax, BigCylinderLz/2, BigCylinderPhiS, BigCylinderPhiE);
  G4LogicalVolume* LogicalBigCylinder = new G4LogicalVolume(SolidBigCylinder, Vacuum, "LogicalBigCylinder");

  G4VPhysicalVolume* PhysicalBigCylinder = new G4PVPlacement(0,			       // no rotation
  							     G4ThreeVector(0,0,0.*cm), // at (0,0,0)
							     "PhysicalBigCylinder",    // its name
							     LogicalBigCylinder,       // its logical volume
							     physiWorld,	       // its mother  volume
							     false,		       // not used
							     0);		       // copy number

  // (Step 2: Replicate Daughter Volume (5x))

  G4double SmallCylinderRMin =  10.*cm;
  G4double SmallCylinderRMax =  20.*cm;
  G4double SmallCylinderLz   =  10.*cm;
  G4double SmallCylinderPhiS =   0.*deg;
  G4double SmallCylinderPhiE = 360.*deg;

  G4Tubs* SolidSmallCylinder = new G4Tubs("SolidSmallCylinder", SmallCylinderRMin, SmallCylinderRMax, SmallCylinderLz/2., SmallCylinderPhiS, SmallCylinderPhiE);

  G4LogicalVolume* LogicalSmallCylinder = new G4LogicalVolume(SolidSmallCylinder, Vacuum, "LogicalSmallCylinder");

  G4PVReplica* repSmallCylinder= new G4PVReplica("Linear Array",
 					         LogicalSmallCylinder,
 					         LogicalBigCylinder,
 					         kZAxis,
 					         5,
 					         10.*cm);

  // (Step 3: Place Detector Object inside Replicated Volumes)

  G4double SmallCylinderRMin_Si =  10.*cm;
  G4double SmallCylinderRMax_Si =  20.*cm;
  G4double SmallCylinderLz_Si   =   2.*cm;
  G4double SmallCylinderPhiS_Si =   0.*deg;
  G4double SmallCylinderPhiE_Si = 360.*deg;

  G4Tubs* SolidSmallCylinder_Si = new G4Tubs("SolidSmallCylinder_Si", SmallCylinderRMin_Si, SmallCylinderRMax_Si, SmallCylinderLz_Si/2, SmallCylinderPhiS_Si, SmallCylinderPhiE_Si);

  G4LogicalVolume* LogicalSmallCylinder_Si = new G4LogicalVolume(SolidSmallCylinder_Si, Vacuum, "LogicalSmallCylinder_Si");

  G4VPhysicalVolume* repSmallCylinder_Si = new G4PVPlacement(0,			       // no rotation
 							     G4ThreeVector(0,0,0.*cm), // at (0,0,0)
							     "PhysicalBigCylinder_Si", // its name
							     LogicalSmallCylinder_Si,  // its logical volume
							     repSmallCylinder,	       // its mother  volume
							     false,		       // not used
							     0);		       // copy number

  // Replication in Phi direction

  // (Step 4: Mother Volume "EndCap" for Replicas)

  G4double MCylinderRMin =   5. *cm;
  G4double MCylinderRMax =  30. *cm;
  G4double MCylinderLz =     0.5*cm;
  G4double MCylinderPhiS =   0. *deg;
  G4double MCylinderPhiE = 360. *deg;

  G4Tubs* SolidMCylinder = new G4Tubs("SolidMCylinder", MCylinderRMin, MCylinderRMax, MCylinderLz/2, MCylinderPhiS, MCylinderPhiE);
  G4LogicalVolume* LogicalMCylinder = new G4LogicalVolume(SolidMCylinder, Vacuum, "LogicalMCylinder");

  G4VPhysicalVolume* PhysicalMCylinder = new G4PVPlacement(0,			       // no rotation
							   G4ThreeVector(0,0,-30.*cm), // at (0,0,-30 cm)
							   "PhysicalMCylinder",	       // its name
							   LogicalMCylinder,	       // its logical volume
							   physiWorld,		       // its mother  volume
							   false,		       // not used
							   0);			       //copy number

  // (Step 5: Replicate Daughter Volume (8x))

  G4RotationMatrix* rot = new G4RotationMatrix();
  rot->rotateZ(0.*deg);

  G4double CylinderRMin =  5. *cm;
  G4double CylinderRMax = 30. *cm;
  G4double CylinderLz   =  0.5*cm;
  G4double CylinderPhiS =  0. *deg;
  G4double CylinderPhiE = 45. *deg;

  G4Tubs* SolidCylinder = new G4Tubs("SolidCylinder", CylinderRMin, CylinderRMax, CylinderLz/2, CylinderPhiS, CylinderPhiE);
  G4LogicalVolume* LogicalCylinder = new G4LogicalVolume(SolidCylinder, Vacuum, "LogicalCylinder");

  G4PVReplica* repRZPhi = new G4PVReplica("RZPhiSlices",
					  LogicalCylinder,
					  LogicalMCylinder,
					  kPhi,
					  8, 
					  (M_PI/4.)*rad,
					  0);

  // (Step 6: Place Detector Object inside Replicated Volumes)

  G4double CylinderRMin_w =  5. *cm;
  G4double CylinderRMax_w = 30. *cm;
  G4double CylinderLz_w =    0.5*cm;
  G4double CylinderPhiS_w =  0. *deg;
  G4double CylinderPhiE_w = 30. *deg;
  
  G4Tubs* SolidCylinder_w = new G4Tubs("SolidCylinder", CylinderRMin_w, CylinderRMax_w, CylinderLz_w/2, CylinderPhiS_w, CylinderPhiE_w);
  G4LogicalVolume* LogicalCylinder_w = new G4LogicalVolume(SolidCylinder_w, Vacuum, "LogicalCylinder_w");

  G4VPhysicalVolume* PhysicalCylinder_w = new G4PVPlacement(0,		              // no rotation
					                    G4ThreeVector(0,0,0.*cm), // at (0,0,0)
					                    "PhysicalCylinder_w",     // its name
					                    LogicalCylinder_w,	      // its logical volume
					                    repRZPhi,		      // its mother  volume
					                    false,		      // not used
					                    0);			      // copy number

  // (Step 7: Second "EndCap")

  PhysicalMCylinder = new G4PVPlacement(0,			   // no rotation
				        G4ThreeVector(0,0,30.*cm), // at (0,0,30 cm)
					"PhysicalMCylinder",	   // its name
					LogicalMCylinder,	   // its logical volume
					physiWorld,		   // its mother  volume
					false,			   // not used
					1);			   // copy number

  // Visualization attributes

  G4VisAttributes* yellow = new G4VisAttributes( G4Colour(255/255., 255/255.,   0/255.) );
  //G4VisAttributes* red    = new G4VisAttributes( G4Colour(255/255.,   0/255.,   0/255.) );
  //G4VisAttributes* roux   = new G4VisAttributes( G4Colour(204/255.,   0/255.,  51/255.) );
  //G4VisAttributes* brown  = new G4VisAttributes( G4Colour(255/255., 153/255., 153/255.) );
  //G4VisAttributes* metal  = new G4VisAttributes( G4Colour(204/255., 204/255., 255/255.) );
  //G4VisAttributes* Lbleu  = new G4VisAttributes( G4Colour(  0/255., 204/255., 204/255.) );
  G4VisAttributes* Lgreen = new G4VisAttributes( G4Colour(153/255., 255/255., 153/255.) );

  // (Step 8: Visualization Attributes)

  logicWorld->SetVisAttributes(G4VisAttributes::Invisible); // hide the box of the World volume
  //logicWorld->SetVisAttributes(red);

  LogicalBigCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalSmallCylinder->SetVisAttributes(G4VisAttributes::Invisible);

  LogicalMCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalSmallCylinder_Si->SetVisAttributes(Lgreen);

  LogicalCylinder->SetVisAttributes(G4VisAttributes::Invisible);
  LogicalCylinder_w->SetVisAttributes(yellow);

  // (Step 9: Final Check)

  return physiWorld;
}

//----------------------------------------------------------------------
