// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysDetectorConstruction.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4Material.hh"

#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4ios.hh"

//***** Here don't forget to incude basic geometry classes: example #include "G4Box.hh"
#include "G4Box.hh"

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

DetectorPhysDetectorConstruction::~DetectorPhysDetectorConstruction() {
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::Construct() {
  DefineMaterials();
  return ConstructSetUp();
}

void DetectorPhysDetectorConstruction::DefineMaterials() { 
  // This function illustrates the possible ways to define materials

  G4String name;
  G4double A, Z, density;
  G4double temperature, pressure;
  G4int ncomponents, natoms;

  G4Element* H  = new G4Element("Hydrogen",name="H" , Z= 1., A=  1.01*g/mole);
  G4Element* O  = new G4Element("Oxygen"  ,name="O" , Z= 8., A= 16.00*g/mole);

  // Vacuum material
  name        = "Vacuum";
  density     = universe_mean_density;
  pressure    = 3.e-18*pascal;
  temperature = 2.73*kelvin;
  Z=1.;
  A=1.01*g/mole;
  Vacuum = new G4Material(name, Z, A , density, kStateGas,temperature,pressure);

  H2O =  new G4Material("Water", density= 1.000*g/cm3, ncomponents=2);
  H2O->AddElement(H, natoms=2);
  H2O->AddElement(O, natoms=1);

  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//----------------------------------------------------------------------

G4VPhysicalVolume* DetectorPhysDetectorConstruction::ConstructSetUp() {
  //
  // World
  //
  G4double WorldSizeX = 1.*m;
  G4double WorldSizeY = 1.*m;
  G4double WorldSizeZ = 1.*m;

  G4Box* solidWorld = new G4Box("World",                                   // its name
                                WorldSizeX/2, WorldSizeY/2, WorldSizeZ/2); // its size

  G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, // its solid
                                                    Vacuum,     // defaultMaterial,
                                                    "World");   // its name

  G4VPhysicalVolume* physiWorld = new G4PVPlacement(0,               // no rotation
                                                    G4ThreeVector(), // at (0,0,0)
                                                    "World",         // its name
                                                    logicWorld,      // its logical volume
                                                    0,               // its mother  volume
                                                    false,           // not used
                                                    0);              // copy number

  //
  // Chamber Gas Box
  //
  //####
  //#### Task A: Implement a Box at (0,0,0) (Do not forget to include the "G4Box.hh")
  //####

  //G4double ChamberGasBoxX = 10.*cm;
  //G4double ChamberGasBoxY = 10.*cm;
  //G4double ChamberGasBoxZ = 10.*cm;

  //#### Task A-1: Once you are done, compile your c++ code (using "make")
  //#### Task A-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task A-3: Check whether your geometry is OK using the command "/geometry/test/run"!

  //G4Box* SolidChamberGasBox = new G4Box("SolidChamberGasBox",                                  // its name
  //                                      ChamberGasBoxX/2, ChamberGasBoxY/2, ChamberGasBoxZ/2); // its size

  //G4LogicalVolume* LogicalChamberGasBox = new G4LogicalVolume(SolidChamberGasBox,      // its solid
  //                                                            Vacuum,                  // its material
  //                                                            "LogicalChamberGasBox"); // its name

  //G4VPhysicalVolume* PhysicalChamberGasBox = new G4PVPlacement(0,                       // no rotation
  //                                                             G4ThreeVector(0,0,0),    // at (0,0,0)
  //                                                             "PhysicalChamberGasBox", // its name
  //                                                             LogicalChamberGasBox,    // its logical volume
  //                                                             physiWorld,              // its mother  volume
  //                                                             false,                   // not used
  //                                                             0);                      // copy number

  //####
  //#### Task B: Implement a Cylinder (or Tube) (Do not forget to include the right ".hh" file. You can have a look into the documentation.)
  //####         Make sure that this volume is adjacent to the previous volume as shown in the figure (see fig in the exercise of the tutorial)

  //G4double Rmin      =   0.*cm;
  //G4double Rmax      =   5.*cm;
  //G4double Lc        =  10.*cm;
  //G4double StartPhi1 =   0.*deg;
  //G4double DeltaPhi1 = 360.*deg;

  //#### Task B-1: Once you are done, compile your c++ code (using "make")
  //#### Task B-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task B-3: Check whether your geometry is OK using the command "/geometry/test/run"!


  //####
  //#### Task C: Implement a Cone (Do not forget to include the right ".hh" file. You can have a look into the documentation.)
  //####         Make sure that this volume is adjacent to the previous volume as shown in the figure (see fig in the exercise of the tutorial)

  //G4double Rmin1     =   0. *cm;  // at -L
  //G4double Rmax1     =   5. *cm;  // at -L
  //G4double Rmin2     =   0. *cm;  // at +L
  //G4double Rmax2     =   2.5*cm;  // at +L
  //G4double L         =  10. *cm;
  //G4double StartPhi2 =   0.*deg;
  //G4double DeltaPhi2 = 360.*deg;

  //#### Task C-1: Once you are done, compile your c++ code (using "make")
  //#### Task C-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task C-3: Check whether your geometry is OK using the command "/geometry/test/run"!


  //####
  //#### Task D: Implement a Sphere (Do not forget to include the right ".hh" file. You can have a look into the documentation.)
  //####         Make sure that this volume is adjacent to the previous volume as shown in the figure (see fig in the exercise of the tutorial)

  //G4double Rmin_s       =   0.*cm;
  //G4double Rmax_s       =   5.*cm;
  //G4double StartPhi_s   =   0.*deg;
  //G4double DeltaPhi_s   = 360.*deg;
  //G4double StartTheta_s =   0.*deg;
  //G4double DeltaTheta_s = 180.*deg;

  //#### Task D-1: Once you are done, compile your c++ code (using "make")
  //#### Task D-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task D-3: Check whether your geometry is OK using the command "/geometry/test/run"!


  //####
  //#### Task E: Implement a Full Solid Sphere (Do not forget to include the right ".hh" file. You can have a look into the documentation.)
  //####         Make sure that this volume is adjacent to the previous volume as shown in the figure (see fig in the exercise of the tutorial)

  //G4double RSphere = 5.*cm;

  //#### Task E-1: Once you are done, compile your c++ code (using "make")
  //#### Task E-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task E-3: Check whether your geometry is OK using the command "/geometry/test/run"!


  //####
  //#### Task F: Implement a Trapezoid (Do not forget to include the right ".hh" file. You can have a look into the documentation.)
  //####         Make sure that this volume is adjacent to the previous volume as shown in the figure (see fig in the exercise of the tutorial)

  //G4double dx1 = 10. *cm;
  //G4double dx2 =  2.5*cm;
  //G4double dy1 = 10. *cm;
  //G4double dy2 =  2.5*cm;
  //G4double dz  = 10. *cm;

  //#### Task F-1: Once you are done, compile your c++ code (using "make")
  //#### Task F-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)
  //#### Task F-3: Check whether your geometry is OK using the command "/geometry/test/run"!


  // Visualization attributes

  logicWorld->SetVisAttributes (G4VisAttributes::Invisible); // hide the box of the World volume

  //G4VisAttributes* yellow = new G4VisAttributes( G4Colour(255/255., 255/255.,   0/255.) );
  //G4VisAttributes* red    = new G4VisAttributes( G4Colour(255/255.,   0/255.,   0/255.) );
  //G4VisAttributes* roux   = new G4VisAttributes( G4Colour(204/255.,   0/255.,  51/255.) );
  //G4VisAttributes* brown  = new G4VisAttributes( G4Colour(255/255., 153/255., 153/255.) );
  //G4VisAttributes* metal  = new G4VisAttributes( G4Colour(204/255., 204/255., 255/255.) );
  //G4VisAttributes* Lbleu  = new G4VisAttributes( G4Colour(  0/255., 204/255., 204/255.) );
  //G4VisAttributes* Lgreen = new G4VisAttributes( G4Colour(153/255., 255/255., 153/255.) );

  //####
  //#### Task G: Visualize your geometry using different colors (defined above).(see example below)
  //####

  //#### Task G-1: Once you are done, compile your c++ code (using "make")
  //#### Task G-2: Then execute if it compiles. The executable is in the current directory (To execute use simply: ./DetectorPhys_T1)

  //LogicalChamberGasBox->SetVisAttributes(yellow);


  return physiWorld;
}

//----------------------------------------------------------------------
