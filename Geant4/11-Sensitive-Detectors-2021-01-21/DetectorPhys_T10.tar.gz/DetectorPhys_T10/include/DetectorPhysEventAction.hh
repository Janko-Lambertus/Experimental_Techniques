// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysEventAction_h
#define DetectorPhysEventAction_h 1

#include "G4UserEventAction.hh"
#include "G4THitsMap.hh"
#include "globals.hh"

//----------------------------------------------------------------------

class DetectorPhysEventAction : public G4UserEventAction {
  public:
    DetectorPhysEventAction();
    virtual ~DetectorPhysEventAction();

    virtual void BeginOfEventAction(const G4Event*);
    virtual void EndOfEventAction(const G4Event*);

  private:
    // methods
    G4THitsMap<G4double>* GetHitsCollection(G4int hcID, const G4Event* event) const;
    G4double GetSum(G4THitsMap<G4double>* hitsMap) const;

    // data members
    G4int fWedgeTotalDoseHCID;
};

//----------------------------------------------------------------------

#endif
