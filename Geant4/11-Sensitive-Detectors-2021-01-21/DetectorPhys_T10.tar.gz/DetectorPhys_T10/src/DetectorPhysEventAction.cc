// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysEventAction.hh"

#include "G4SystemOfUnits.hh"

#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4VVisManager.hh"
#include "G4UImanager.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"
#include "G4HCofThisEvent.hh"

//----------------------------------------------------------------------

DetectorPhysEventAction::DetectorPhysEventAction()
  : G4UserEventAction(), fWedgeTotalDoseHCID(-1) {
}

//----------------------------------------------------------------------

DetectorPhysEventAction::~DetectorPhysEventAction() {
}


//----------------------------------------------------------------------

// Begin of Event Action
void DetectorPhysEventAction::BeginOfEventAction(const G4Event* /*evt*/) {
}

//----------------------------------------------------------------------

// End of Event Action
void DetectorPhysEventAction::EndOfEventAction(const G4Event* evt) {
  // Get hit collection ID
  if ( fWedgeTotalDoseHCID == -1 ) {
    fWedgeTotalDoseHCID = G4SDManager::GetSDMpointer()->GetCollectionID("Wedge/TotalDose");
  }
  G4double totalDose = GetSum(GetHitsCollection(fWedgeTotalDoseHCID, evt));
  G4int eventID = evt->GetEventID();
  G4cout << "---> End of event: " << eventID << "  Total dose in all wedges (petals): " << totalDose / gray << " Gy" << G4endl;     
}  

//----------------------------------------------------------------------

G4THitsMap<G4double>* DetectorPhysEventAction::GetHitsCollection(G4int hcID, const G4Event* event) const {
  G4THitsMap<G4double>* hitsCollection 
    = static_cast<G4THitsMap<G4double>*>(
        event->GetHCofThisEvent()->GetHC(hcID));
  
  if ( ! hitsCollection ) {
    G4ExceptionDescription msg;
    msg << "Cannot access hitsCollection ID " << hcID; 
    G4Exception("DetectorPhysEventAction::GetHitsCollection()",
      "MyCode0003", FatalException, msg);
  }         

  return hitsCollection;
}    

//----------------------------------------------------------------------

G4double DetectorPhysEventAction::GetSum(G4THitsMap<G4double>* hitsMap) const {
  G4double sumValue = 0;
  std::map<G4int, G4double*>::iterator it;
  G4cout << "Sum:" << G4endl;
  for ( it = hitsMap->GetMap()->begin(); it != hitsMap->GetMap()->end(); it++) {
    G4cout << it->first << ": " << *(it->second) << G4endl;
    sumValue += *(it->second);
  }
  return sumValue;
}

//----------------------------------------------------------------------
