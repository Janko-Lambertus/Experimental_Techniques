// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysRunAction_h
#define DetectorPhysRunAction_h 1

#include "G4UserRunAction.hh"
#include "globals.hh"

class G4Run;

//----------------------------------------------------------------------

class DetectorPhysRunAction : public G4UserRunAction {
  public:
    DetectorPhysRunAction();
    virtual ~DetectorPhysRunAction();

    virtual void BeginOfRunAction(const G4Run*);
    virtual void EndOfRunAction(const G4Run*);
};

//----------------------------------------------------------------------

#endif
