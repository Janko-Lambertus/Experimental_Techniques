// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysEventAction_h
#define DetectorPhysEventAction_h 1

#include "DetectorPhysRunAction.hh"
#include "G4UserEventAction.hh"
#include "globals.hh"

//----------------------------------------------------------------------

class DetectorPhysEventAction : public G4UserEventAction {
  public:
    DetectorPhysEventAction(DetectorPhysRunAction*);
    virtual ~DetectorPhysEventAction();

    virtual void BeginOfEventAction(const G4Event*);
    virtual void EndOfEventAction(const G4Event*);

    G4int GetEventNo();

  private:
};

//----------------------------------------------------------------------

#endif
