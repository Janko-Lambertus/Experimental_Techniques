// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#ifndef DetectorPhysSteppingAction_h
#define DetectorPhysSteppingAction_h 1

#include "G4UserSteppingAction.hh"
#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4ios.hh"
#include "globals.hh"

#include "G4VSteppingVerbose.hh"
#include "G4VSensitiveDetector.hh"
#include "G4StepStatus.hh"

#include "DetectorPhysEventAction.hh"
#include "DetectorPhysRunAction.hh"
#include "DetectorPhysDetectorConstruction.hh"

class G4Step;
class DetectorPhysEventAction;

//----------------------------------------------------------------------

class DetectorPhysSteppingAction : public G4UserSteppingAction {
  public:
    DetectorPhysSteppingAction(DetectorPhysEventAction*, DetectorPhysRunAction*);
    virtual ~DetectorPhysSteppingAction();

    virtual void UserSteppingAction(const G4Step* step );
  
  private:
    DetectorPhysEventAction*          eventaction;
    DetectorPhysRunAction*            runaction;

    const G4ParticleDefinition* aDef;
  
    G4int evtNb;
};

//----------------------------------------------------------------------

#endif

