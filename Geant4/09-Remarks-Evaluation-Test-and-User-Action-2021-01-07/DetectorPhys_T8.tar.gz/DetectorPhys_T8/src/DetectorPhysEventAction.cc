// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysEventAction.hh"

#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4VVisManager.hh"
#include "G4UImanager.hh"
#include "G4ios.hh"

//----------------------------------------------------------------------

DetectorPhysEventAction::DetectorPhysEventAction(DetectorPhysRunAction* DetectorPhysRA) {
}

//----------------------------------------------------------------------

DetectorPhysEventAction::~DetectorPhysEventAction() {
}


//----------------------------------------------------------------------

// Begin of Event Action
void DetectorPhysEventAction::BeginOfEventAction(const G4Event* evt) {
}

//----------------------------------------------------------------------

// End of Event Action
void DetectorPhysEventAction::EndOfEventAction(const G4Event* evt) {
}  

//----------------------------------------------------------------------

G4int DetectorPhysEventAction::GetEventNo() {
  G4int evno = fpEventManager->GetConstCurrentEvent()->GetEventID() ;

  return evno ;
}

//----------------------------------------------------------------------
