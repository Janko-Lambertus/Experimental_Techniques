// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysSteppingAction.hh"

#include "globals.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4RunManager.hh"
#include "G4VProcess.hh"
#include "G4SteppingManager.hh"
#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4Trajectory.hh"

#include "DetectorPhysEventAction.hh"
#include "DetectorPhysRunAction.hh"

//----------------------------------------------------------------------

DetectorPhysSteppingAction::DetectorPhysSteppingAction(DetectorPhysEventAction* EA, DetectorPhysRunAction* RA)
  : eventaction (EA), runaction (RA) {
}

//----------------------------------------------------------------------

DetectorPhysSteppingAction::~DetectorPhysSteppingAction() { 
}

//----------------------------------------------------------------------

void DetectorPhysSteppingAction::UserSteppingAction(const G4Step* aStep ) {
  evtNb = eventaction->GetEventNo();
}

//----------------------------------------------------------------------
