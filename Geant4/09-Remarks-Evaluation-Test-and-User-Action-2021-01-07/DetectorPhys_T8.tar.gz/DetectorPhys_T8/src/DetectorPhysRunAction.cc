// *********************************************************************
// *                                                                   *
// *            Experimental Techniques in Particle Physics            *
// *                                                                   *
// * Geant 4 Tutorials -- Detector physics                             *
// * RWTH Aachen University                                            *
// * Karim LAIHEM and Andreas NOWACK                                   *
// *********************************************************************
//
//----------------------------------------------------------------------

#include "DetectorPhysRunAction.hh"
#include "DetectorPhysPrimaryGeneratorAction.hh"
#include "G4Run.hh"
#include "G4UImanager.hh"
#include "G4VVisManager.hh"
#include "G4ios.hh"

//----------------------------------------------------------------------

DetectorPhysRunAction::DetectorPhysRunAction() {
}

//----------------------------------------------------------------------

DetectorPhysRunAction::~DetectorPhysRunAction() {
}

//----------------------------------------------------------------------

// Begin of Run Action
void DetectorPhysRunAction::BeginOfRunAction(const G4Run* aRun) {
}

//----------------------------------------------------------------------

// End of Run Action
void DetectorPhysRunAction::EndOfRunAction(const G4Run* aRun) {
}

//----------------------------------------------------------------------
