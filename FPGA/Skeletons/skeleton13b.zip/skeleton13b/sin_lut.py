#!/bin/python

import numpy as np

lut_addr = np.arange(0,16)

print (lut_addr)

lut_content = np.sin( lut_addr/15. * np.pi/2. ) * 255
lut_content = lut_content.astype(int)

print(lut_content)

for addr, content in zip(lut_addr, lut_content):
    print("when %d =>   y <= %d"%(addr, content))








